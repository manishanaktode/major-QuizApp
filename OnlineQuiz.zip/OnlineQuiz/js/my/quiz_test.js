
let quiz  = [
    {
        question: "There are two pipes which are functioning simultaneouly to fill a tank in 12 hours, if one pipe fills the tank 10 hours faster than other then how many hours second pipe will take to fill the tank ?"
        ,
        option: [
            "30 hours",
            "35 hours",
            "40 hours",
            "45 hours",],
        answer: 1,
    
    },
    {
        question:"A cistern can be filled in 9 hours but due to a leak at its bottom it takes 10 hours. If the cistern is full, then the time that the leak will take to make it empty will be ?"
        ,
        option: [
            "20 hours",
            "19 hours",
            "80 hours",
            "90 hours",],
        answer:3,

    },
    {
        question:"One pipe can fill a tank three times as fast as another pipe. If together the two pipes can fill the tank in 36 minutes, then the slower pipe alone will be able to fill the tank in"
        ,
        option: [
            "144 mins",
            "123 mins",
            "111 mins",
            "145 mins",
        ],
        answer:2,

    },
    {
        question:"12 buckets of water fill a tank when the capacity of each tank is 13.5 litres. How many buckets will be needed to fill the same tank, if the capacity of each bucket is 9 litres?"
        ,
        option: [
            " 15 buckets",
            "16 buckets",
            "17 buckets",
            "18 buckets",
        ],
       
        answer:4,

    },

    {
        question:"A tap can fill a tank in 6 hours. After half the tank is filled then 3 more similar taps are opened. What will be total time taken to fill the tank completely?"
     
        ,
        option: [
            "2 hours 20 mins",
            "2 hours 3 mins",
            "3 hours 40 mins",
            "3 hours 20 mins",
        ],
       
        answer:1,

    },
    {
        question:"Pipe A can fill a tank in 5 hours, pipe B in 10 hours and pipe C in 30 hours. If all the pipes are open, in how many hours will the tank be filled ?"
        
        ,
        option: [
            "5 hours",
            "2 hours",
            "2.5 hours",
            "1 hours",
        ],
       
        answer:3,

    },
    {
        question:"Two pipes A and B can fill a tank in 6 hours and 4 hours respectively. If they are opened on alternate hours and if pipe A is opened first, in how many hours, the tank shall be full ?"
        
        ,
        option: [
            "15 buckets",
            "16 buckets",
            "17 buckets",
            "18 buckets",
        ],
       
        answer:4,

    },
    {
        question:"It takes two pipes A and B, running together, to fill a tank in 6 minutes. It takes A 5 minutes less than B to fill the tank, then what will be the time taken by B alone to fill the tank?"
        ,
        option: [
            "15 buckets",
            "16 buckets",
            "17 buckets",
            "18 buckets",
        ],
      
        answer:4,

    },
    {
        question:"If two pipes can fill a tank in 24 and 20 minutes respectively and another pipe can empty 3 gallons of water per minute from that tank. When all the three pipes are working together, it takes 15 minutes to fill the tank. What is the capacity of the tank?"
        ,
        option: [
            "100 gallons",
            "120 gallons",
            "130 gallons",
            "140 gallons",
        ],
      
        answer:2,

    },
    {
        question:" Pipe A can fill the tank 3 times faster in comparison to pipe B. It takes 36 minutes for pipe A and B to fill the tank together. How much time will pipe B alone take to fill the tank?"
        ,
        option: [
            "100 minutes",
            "134 minutes",
            "124 minutes",
            "144 minutes",
        ],
        
        answer:2,

    },

] 
