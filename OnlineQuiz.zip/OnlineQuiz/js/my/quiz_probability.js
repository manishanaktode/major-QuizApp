
let quiz = [
    {
        question: "In a cycle race there are 5 persons named as J,K,L,M,N participated for 5 positions. How many number of ways can M finishes always before N?"
        ,
        option: [
            "20",
            "36",
            "55",
            "60",
        ],
       
        answer:4,
    
    },
    {
        question:"A box contains 3 blue marbles, 4 red, 6 green marbles and 2 yellow marbles. If three marbles are picked at random, what is the probability that they are all blue??"
        ,
        option: [
            "1/455",
            "2/455",
            "4/455",
            "1/91",],
       
        answer:1,

    },
    {
        question:". A Bag contains 6 Blue Balls and 4 Red Balls. 4 balls are picked at random. What is the probability that 2 are Blue and 2 are Red?"
        ,
        option: [
            "1/5",
            "1/7",
            "3/7",
            "3/8",
        ],
       
        answer:2,

    },
    {
        question:"A Bag contains 6 Blue Balls and 4 Red Balls. 3 balls are picked at random. What is the probability that 3 are Blue or 3 are Red?"
        ,
        option: [
            "1/5",
            "1/6",
            "1/7",
            "1/8",
        ],
        
        answer:1,

    },

    {
        question:" A Bag contains 6 Blue Balls and 4 Red Balls. 5 balls are picked at random. What is the probability that 3 are Blue and 2 are Red or 2 are Blue and 3 are Red? ?"
     
        ,
        option: [
            "3/7",
            "4/7",
            "5/7",
            "6/7",
        ],
       
        answer:3,

    },
    {
        question:" A Bag contains 6 Blue Balls and 4 Red Balls. 3 balls are picked at random. What is the prob. that none of them is Red? ?"
        
        ,
        option: [
            "1/3",
            "1/5",
            "1/6",
            "1/7",
        ],
       
        answer:3,

    },
    {
        question:"The probability that A speaks truth is 3/5 and that of B speaking truth is 4/7. What is the probability that they agree in stating the same fact??"
        
        ,
        option: [
            "12/35",
            "15/35",
            "18/35",
            "21/35",
        ],
       
        answer:3,

    },
    {
        question:" A box contains 3 blue marbles, 4 red, 6 green marbles and 2 yellow marbles. If four marbles are picked at random, what is the probability that none is blue??"
        ,
        option: [
            "33/91",
            "34/98",
            "17/67",
            "3/65",
        ],
       
        answer:1,

    },
    {
        question:"If a card is drawn from a well shuffled pack of cards, the probability of drawing a spade or a king is:?"
        ,
        option: [
            " 19/52",
            "4/13",
            " 17/52",
            " 5/13",
        ],
        
        answer:2,

    },
    {
        question:"Three 6 faced dice are thrown together. The probability that all the three show the same number on them is:?"
        ,
        option: [
            " 1/64",
            " 1/36",
            " 1/14",
            " 1/44",
        ],
       
        answer:2,

    },

] 

