
let quiz = [
    {
        question:"The present age of Aradhana and Aadrika is in the ratio 3:4. 5 years back, the ratio of their ages was 2:3. What is the present age of Aradhana?"
        ,
        option: [
            "12 years",
            "15 years",
            "5 years",
            "14 years",
        ],
        
        answer:2,
    
    },
    {
        question:"If the total ages of Iqbal and Shikhar is 12 years more than the total age of Shikhar and Charu. Charu is how many years younger than Iqbal?"
        ,
        option: [
            "11 years",
            "2 years",
            " 13 years",
            "none of the above",
        ],
        
        answer:4,

    },
    {
        question:"A father is twice as old as his daughter. If 20 years ago, the age of the father was 10 times the age of the daughter, what is the present age of the father?"
        ,
        option: [
            "40 years",
            "32 years",
            "43 years",
            "45 years",
        ],
        
        answer:4,

    },
    {
        question:"Arun is 2 years older than Bharat who is twice as old as Charat. If the total of the ages of Arun, Bharat and Charat be 27, then how old is Bharat?"
        ,
        option: [
            "10 years",
            "11 years",
            "12 years",
            "13 years",
        ],
       
        answer:1,

    },

    {
        question:"The sum of the ages of a daughter and mother is 56 years; after four years the age of the mother will be three times that of the daughter. What is the age of the daughter and the mother, respectively? ?"
     
        ,
        option: [
            "12 years,41 years",
            "11 years,34 years",
            "13 years,4 years",
            "12 years,44 years",
        ],
        
        answer:4,

    },
    {
        question:"The average age of 8 men increases by 2 years when two women are included in place of two men of ages 20 and 24 years. Find the average age of the women?"
        
        ,
        option: [
            "33 year",
            "30 year",
            "23 year",
            "19 year",
        ],
       
        answer:2,

    },
    {
        question:"The average age of husband, wife and their child 3 years ago was 27 years and that of wife and the child 5 years ago was 20 years. The present age of the husband is:?"
        
        ,
        option: [
            " 41 years",
            " 40 years",
            " 23 years",
            " 32 years",
        ],
        
        answer:2,

    },
    {
        question:"A is 2 years older than B who is twice as old as C. If the total of the ages of A, B and C be 27, then how old is B?"
        ,
        option: [
            "7 years",
            "8 years",
            "9 years",
            "10 years",
        ],
        
        answer:1,

    },
    {
        question:"A person's present age is two-fifth of the age of his mother. After 8 years, he will be one-half of the age of his mother. How old id the mother at present??"
        ,
        option: [
            "32 years",
            "33 years",
            "40 years",
            "47 years",
        ],
        
        answer:3,

    },
    {
        question:"Three 6 faced dice are thrown together. The probability that all the three show the same number on them is A father said to his son, 'I was as old as you are at present at the time of your birth.' If the father's age is 38 years now, the son's age five years back was::?"
        ,
        option: [
            "14 years",
            "13 years",
            "16 years",
            "18 years",
        ],
        
        answer:1,

    },

] 


