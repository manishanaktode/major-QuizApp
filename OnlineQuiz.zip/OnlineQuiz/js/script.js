let index = 0;
let attempt = 0;
let score = 0;
let wrong = 0;

let min = 0;
let sec = 0;



let participanName = localStorage.userName;

let questions = quiz.sort(function () {
    return 0.5 - Math.random();
});

let totalQuestion = questions.length;

$(function () {
    // timer code start from here

    let totaTime = 0; // 200 seconds for timer
    let counter = 0;
    let secCounter = 0;


    let timer = setInterval(function () {
        counter++;
        min = Math.floor((totaTime + counter) / 60);
        //sec = totaTime + min * 60 + counter;

        secCounter++;
        if (secCounter == 60) {
            secCounter = 1;
        } else {
            sec = secCounter;
        }

    //    console.log("min=" + min);
    //    console.log("sec=" + sec);

        $(".timerBox span").text(min + ":" + sec);

        if (counter == totaTime) {
            alert("Time's up. press ok to show the result.");
            result();
            clearInterval(timer);
        }

    }, 1000);

    // timer code end from here
    printQuestion(index);
});

// Print Question Start

function printQuestion(i) {
    $(".questionBox").text(questions[i].question);
    $(".optionBox span").eq(0).text(questions[i].option[0]);
    $(".optionBox span").eq(1).text(questions[i].option[1]);
    $(".optionBox span").eq(2).text(questions[i].option[2]);
    $(".optionBox span").eq(3).text(questions[i].option[3]);
}

// Print Question End

//Check Answer Start

function checkAnswer(option) {
    attempt++;

    let optionChecked = $(option).data("opt");
   // console.log(optionChecked);

    if (optionChecked == questions[index].answer) {
        $(option).addClass("right");
        score++;
    } else {
        $(option).addClass("wrong");
        wrong++;
    }

    $(".scoreBox span").text(score);

    $(".optionBox span").attr("onclick", "");

}

//Check Answer End


//function show next start

function showNext() {

    if (index >= questions.length-1) {
        showResult(0);
        return;
    }

    index++;

    $(".optionBox span").removeClass();
    $(".optionBox span").attr("onclick", "checkAnswer(this)");
    printQuestion(index);
}

//function show next end


//function to show result start

function showResult(j) {
    if (
        j == 1 &&
        index < questions.length - 1 &&
        !confirm(
            "Quiz has not finalized yet. Press ok to skip quiz & get your final result."
        )
    ) {
        return;

    }

    result();
}

//function to show result end

//function to result start

function result() {
    $("#questionScreen").hide();
    $("#resultScreen").show();

    let totalTime = min + ":" + sec;

    $("#participanName").text(participanName);
    $("#totalTime").text(totalTime);
    $("#totalQuestion").text(totalQuestion);
    $("#attemptQuestion").text(attempt);
    $("#correctAnswer").text(score);
    $("#wrongAnswer").text(wrong);

}

//function to result end